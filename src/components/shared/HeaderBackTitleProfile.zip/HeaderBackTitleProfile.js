import React, { useState } from 'react';
import {
    View,
    Text,
    StyleSheet,
    Image,
    TouchableOpacity
} from 'react-native';
import FastImage from 'react-native-fast-image';
import { ConstantValues } from '../../utils/ConstantValues';
import { colors, fontsProps, paddingProps, dimensionsProps } from '../../utils/StyleComponents';
const VIEW_WIDTH = 35;
export default function HeaderBackTitleProfile({ title, backcolor, headerstyle, headerlogo, profilename, buttonPress, profilePictureURL }) {
    const [imgErr, setImgErr] = useState(false);
    const defaultAvatar =
        'https://www.iosapptemplates.com/wp-content/uploads/2019/06/empty-avatar.jpg';

    const onImageError = () => {
        setImgErr(true);
    };
    const userProfileView = () => {
        if (profilePictureURL == "") {
            return <View style={styles.singleChatItemIcon}>
                <FastImage
                    style={styles.singleChatItemIcon}
                    source={{ uri: defaultAvatar }}
                />
            </View>
        } else {
            return <View style={styles.singleChatItemIcon}>
                <FastImage
                    style={styles.singleChatItemIcon}
                    onError={onImageError}
                    source={imgErr ? { uri: defaultAvatar } : { uri: profilePictureURL }}
                />
            </View>
        }

    }
    return (
        <View style={[headerstyle, {
            height: 60,
            alignItems: "center",
        }]}>
            <View style={{
                flex: 1,
                backgroundColor: "red",
                flexDirection: "row"
            }}>
                <TouchableOpacity
                    onPress={buttonPress}>
                    <View style={{
                        flexDirection: 'row',
                        justifyContent: "center",
                        alignItems: "center",

                    }}>
                        <Image
                            source={headerlogo}
                            style={{
                                width: 20,
                                height: 15,
                                resizeMode: 'contain',
                                alignSelf: 'center'
                            }}
                        />
                        <Text style={{
                            fontSize: fontsProps.lg,
                            color: colors.COLOR_BLACK,
                            fontFamily:
                                Platform.OS === 'ios' ?
                                    "Gilroy-SemiBold" :
                                    "Radomir Tinkov - Gilroy-SemiBold",
                        }}>
                            {headerlogo != null && "Back"}
                        </Text>

                    </View>
                </TouchableOpacity>
                <View style={{
                    // flex: (title === ConstantValues.MESSAGE_LIST) ? 2 : 3,
                    flexDirection: "row",
                    backgroundColor: "red",
                }}>
                    {(title === ConstantValues.MESSAGE_LIST) && userProfileView()}

                    <Text
                        style={{
                            fontSize: fontsProps.xl,
                            color: colors.COLOR_WHITE,
                            marginHorizontal: 10,

                            fontFamily: Platform.OS === 'ios' ?
                                "Gilroy-SemiBold" :
                                "Radomir Tinkov - Gilroy-SemiBold"
                        }}>{profilename}
                    </Text>
                </View>
            </View>



        </View >

    )
}
const styles = StyleSheet.create({
    singleChatItemIcon: {
        height: VIEW_WIDTH,
        borderRadius: VIEW_WIDTH / 2,
        width: VIEW_WIDTH,
    },
});
