// export const TWILIO_SERVER_ENDPOINT =
//   'https://glacial-peak-35311.herokuapp.com';
export const TWILIO_SERVER_ENDPOINT =
  'https://us-central1-socialape-e8afb.cloudfunctions.net/getTwilioAccessToken';
// export const TWILIO_SERVER_ENDPOINT =
//   'https://us-central1-production-a9404.cloudfunctions.net/getTwilioAccessToken';
